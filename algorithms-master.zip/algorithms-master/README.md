algorithms
==========

Assignments for Coursera's Algorithms, Part I course.

I've never written Java before, so this should be interesting.

Let's just go with this one: http://creativecommons.org/licenses/by-nc/3.0/us/deed.en_US
